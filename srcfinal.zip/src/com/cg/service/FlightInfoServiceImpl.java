package com.cg.service;

import java.time.LocalDate;
import java.util.HashMap;
import java.util.List;

import com.cg.ars.bean.FlightInformationBean;
import com.cg.ars.dao.FlightInfoDaoImpl;
import com.cg.ars.dao.IFlightInfoDao;
import com.cg.ars.exception.ARSException;

public class FlightInfoServiceImpl implements IFlightInfoService{
	
	IFlightInfoDao fdao = new FlightInfoDaoImpl();
	

	/**
	 * 
	 */
	
	
	@Override
	public List<FlightInformationBean> viewAllFlightInformation()
			throws ARSException {
		
		return fdao.viewAllFlightInformation();
	}

	@Override
	public FlightInformationBean viewParticularFlightInfo(String flightNumber)
			throws ARSException {
		
		return fdao.viewParticularFlightInfo(flightNumber);
	}

	@Override
	public boolean addFlight(FlightInformationBean bean) throws ARSException {
		
		return fdao.addFlight(bean);
	}

	
	
	@Override
	public boolean deleteFlight(String FlightNo) throws ARSException{
		
		return fdao.deleteFlight(FlightNo);
	}

	@Override
	public FlightInformationBean updateFlightInformation(
			FlightInformationBean flightInfoBean) throws ARSException {
		
		return fdao.updateFlightInformation(flightInfoBean);
	}

	@Override
	public HashMap<String, String> viewOverAllOccupancy(String sourceCity,
			String destinationCity) throws ARSException {
		
		return fdao.viewOverAllOccupancy(sourceCity, destinationCity);
	}

	@Override
	public int viewPeriodOccupancy(String flightNumber, LocalDate fromDate,
			LocalDate toDate) throws ARSException {
		// TODO Auto-generated method stub
		return fdao.viewPeriodOccupancy(flightNumber, fromDate, toDate);
	}

	

	

}
