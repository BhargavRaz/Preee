package com.cg.test;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.BeforeClass;
import org.junit.Test;

import com.cg.ars.dao.IUserDao;
import com.cg.ars.dao.UserDaoImpl;
import com.cg.ars.exception.ARSException;

public class TestLogin {
	
	static IUserDao userDao =null;
	
	@BeforeClass
	public static void initialize() throws Exception {
		userDao =new UserDaoImpl();
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testValidAdminLogin() {
		String userName="Admin";
		String password="Admin";
		String role="Admin";
		try {
			assertTrue(userDao.isValidUser(userName, password, role));
		} catch (ARSException e) {
			System.err.println("Invalid admin details in junit "+e.getMessage());
		}
	}
	
	@Test
	public void testInvalidAdminLogin() {
		String userName="executive";
		String password="haha";
		String role="Admin";
		try {
			assertFalse(userDao.isValidUser(userName, password, role));
		} catch (ARSException e) {
			System.err.println("Invalid admin details in junit "+e.getMessage());
		}
	}
	
	@Test
	public void testValidExecutiveLogin() {
		String userName="executive";
		String password="executive";
		String role="executive";
		try {
			assertTrue(userDao.isValidUser(userName, password, role));
		} catch (ARSException e) {
			System.err.println("Invalid admin details in junit "+e.getMessage());
		}
	}
	
	@Test
	public void testInvalidExecutiveLogin() {
		String userName="Admin";
		String password="haha";
		String role="executive";
		try {
			assertFalse(userDao.isValidUser(userName, password, role));
		} catch (ARSException e) {
			System.err.println("Invalid admin details in junit "+e.getMessage());
		}
	}

}
